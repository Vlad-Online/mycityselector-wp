<?php

namespace Mcs\Interfaces;

interface CityNamesInterface {

}
