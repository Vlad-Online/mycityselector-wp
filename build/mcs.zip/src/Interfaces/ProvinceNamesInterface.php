<?php

namespace Mcs\Interfaces;

interface ProvinceNamesInterface {

}
