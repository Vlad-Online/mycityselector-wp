<?php

namespace Mcs\Interfaces;

interface CountryNamesInterface {

}
